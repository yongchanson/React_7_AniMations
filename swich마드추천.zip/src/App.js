import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import styled from "styled-components";

const items = [1, 2, 3, 4];

const variants = {
  open: { color: "blue" },
  closed: { color: "red", scale: 1.2 }
};

const Background = styled.div`
  background: linear-gradient(to left, #e66465, #9198e5);
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

const Grid = styled.div`
  width: 600px;
  height: 400px;
  display: grid;
  grid-template-rows: repeat(2, 1fr);
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
`;

const Backdrop = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1;
`;

export default function App() {
  const [selectedId, setSelectedId] = useState(null);
  const [switched, setSwitched] = useState(false);

  return (
    <Background>
      <Grid>
        {items.map((item) => (
          <motion.div
            key={item}
            layoutId={item}
            onClick={() => setSelectedId(item)}
            style={{
              borderRadius: 10,
              backgroundColor: "rgba(255,255,255,0.5)",
              cursor: "pointer",
              display: "flex",
              justifyContent: "center",
              alignItems: "center"
            }}
            whileHover={{ scale: 1.05 }}
          >
            {(item === 2) & !switched ? (
              <motion.div
                layoutId="circle"
                style={{
                  backgroundColor: "white",
                  width: 70,
                  height: 70,
                  borderRadius: "50%",
                  boxShadow: "1px 1px 5px rgba(0,0,0,0.5)"
                }}
              ></motion.div>
            ) : (
              ""
            )}
            {(item === 3) & switched ? (
              <motion.div
                layoutId="circle"
                style={{
                  backgroundColor: "white",
                  width: 70,
                  height: 70,
                  borderRadius: "50%",
                  boxShadow: "1px 1px 5px rgba(0,0,0,0.5)"
                }}
              ></motion.div>
            ) : (
              ""
            )}
          </motion.div>
        ))}
      </Grid>
      <AnimatePresence>
        {selectedId && (
          <>
            <Backdrop onClick={() => setSelectedId(null)} />
            <motion.div
              layoutId={selectedId}
              style={{
                position: "fixed",
                zIndex: 3,
                width: 420,
                height: 280,
                backgroundColor: "white",
                borderRadius: 10
              }}
            ></motion.div>
          </>
        )}
      </AnimatePresence>
      <motion.button
        style={{
          borderRadius: 5,
          border: 0,
          marginTop: 30,
          fontWeight: 600,
          padding: 10,
          paddingTop: 5,
          paddingBottom: 5,
          color: switched ? "red" : "blue",
          cursor: "pointer"
        }}
        onClick={() => {
          setSwitched((prev) => !prev);
        }}
        animate={switched ? "closed" : "open"}
        variants={variants}
      >
        Switch
      </motion.button>
    </Background>
  );
}
